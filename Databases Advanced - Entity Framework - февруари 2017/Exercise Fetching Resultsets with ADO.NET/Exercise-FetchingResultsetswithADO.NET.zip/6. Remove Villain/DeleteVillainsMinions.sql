﻿USE MinionsDB
DELETE FROM VillainsMinions
WHERE VillainId=@villainId
