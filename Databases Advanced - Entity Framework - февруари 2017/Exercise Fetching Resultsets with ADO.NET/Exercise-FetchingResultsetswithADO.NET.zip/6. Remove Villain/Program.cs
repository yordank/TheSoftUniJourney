﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6.Remove_Villain
{
    class Program
    {
        static void Main(string[] args)
        {
            int villainsId = int.Parse(Console.ReadLine());

            string serverName = "Server=HOME\\SQLEXPRESS; ";
            SqlConnection dbCon = new SqlConnection(
                       serverName +
                       "Integrated Security=true");
            dbCon.Open();

            using (dbCon)
            {
                int deletedRows = DeleteVillainsMinions(villainsId, dbCon);
                DeleteVillain(villainsId, dbCon, deletedRows);

            }

        }

        private static void DeleteVillain(int villainsId, SqlConnection dbCon, int deletedRows)
        {
            string deleteVillainQuery = File.ReadAllText("./../../DeleteVillain.sql");

            SqlCommand cmd = new SqlCommand(deleteVillainQuery, dbCon);

            SqlParameter parametar = new SqlParameter("@Id", villainsId);

            cmd.Parameters.Add(parametar);

            string Name = cmd.ExecuteScalar().ToString();

            if (Name != "")
            {
                Console.WriteLine($"{Name} was deleted");

                Console.WriteLine($"{deletedRows} minions released");
            }
            else
                Console.WriteLine("No such villain was found");
        }

        private static int DeleteVillainsMinions(int villainsId, SqlConnection dbCon)
        {
            string deleteVillainsMinionsQuery = File.ReadAllText("./../../DeleteVillainsMinions.sql");

            SqlCommand cmd = new SqlCommand(deleteVillainsMinionsQuery, dbCon);

            SqlParameter parametar = new SqlParameter("@villainId", villainsId);

            cmd.Parameters.Add(parametar);

            int deletedRows = cmd.ExecuteNonQuery();

            return deletedRows;
           
        }
    }
}
