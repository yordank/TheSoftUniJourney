﻿USE MinionsDB

 
	DECLARE @Name AS VARCHAR(100);
	SET @Name=(SELECT [Name] FROM Villains WHERE Id=@Id)

	 

	IF(@Name IS NOT NULL)
	BEGIN
    DELETE FROM Villains
	WHERE Id=@Id
	SELECT @Name
	END

	SELECT @Name
	
	
 

 
