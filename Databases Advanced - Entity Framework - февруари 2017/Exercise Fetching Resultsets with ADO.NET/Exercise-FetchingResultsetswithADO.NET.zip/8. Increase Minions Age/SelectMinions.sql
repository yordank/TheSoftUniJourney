﻿USE MinionsDB
SELECT Name,
       Age 
  FROM Minions
