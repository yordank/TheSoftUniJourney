﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8.Increase_Minions_Age
{
    class Program
    {
        static void Main(string[] args)
        {

            ////////////////////////
            ////////////////////////
            // IN THIS PROBLEM I USE A USER DEFINED MSSQL FUNCTION dbo.InitCap
            // BE SURE THAT YOU HAVE IT OTHERWISE THE PROGRAM WOULD NOT WORKING PROPERLY
            // FOR MORE DETAILS LOOK AT THE FunctionInitCap.sql FILE
            ///////////////////////
            ///////////////////////
            var ids = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse);

             

            string serverName = "Server=HOME\\SQLEXPRESS; ";
            SqlConnection dbCon = new SqlConnection(
                       serverName +
                       "Integrated Security=true");
            dbCon.Open();

            using (dbCon)
            {
                UpdateMinions(ids, dbCon);

                SelectMinions(dbCon);

            }



        }

        private static void UpdateMinions(IEnumerable<int> ids, SqlConnection dbCon)
        {
            string updateMinionsQuery = $@" USE MinionsDB

                                                UPDATE Minions
                                                SET Name=dbo.InitCap(Name) ,
                                                    Age=Age+1
                                                WHERE Id IN ({string.Join(",", ids)})";

            SqlCommand cmd = new SqlCommand(updateMinionsQuery, dbCon);


            int affectedRows = (int)cmd.ExecuteNonQuery();


            // Console.WriteLine($"{affectedRows}");
        }

        private static void SelectMinions(SqlConnection dbCon)
        {
             string selectMinionsQuery = File.ReadAllText("./../../SelectMinions.sql");

             SqlCommand cmd = new SqlCommand(selectMinionsQuery, dbCon);

             SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
              Console.WriteLine($"{reader["Name"]} {reader["Age"]}");
            }

        }
    }
}
