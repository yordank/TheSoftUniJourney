﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.Add_Minion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Minion: ");
            var inputMinion = Console.ReadLine().Split(new char[] { ' ' },StringSplitOptions.RemoveEmptyEntries);

            Console.Write("Villain: ");
            var inputVillain = Console.ReadLine();

            string town = inputMinion[2];

            string serverName = "Server=HOME\\SQLEXPRESS; ";
            SqlConnection dbCon = new SqlConnection(
                       serverName +
                       "Integrated Security=true");
            dbCon.Open();

            using (dbCon)
            {
                InsertTown(town, dbCon);

                InsertVillain(inputVillain, dbCon);

                InsertMinion(inputMinion, inputVillain, dbCon);

            }


        }

        private static void InsertMinion(string[] inputMinion, string inputVillain, SqlConnection dbCon)
        {
            string insertQuery = File.ReadAllText("./../../InsertMinion.sql");

            SqlCommand cmd = new SqlCommand(insertQuery, dbCon);

            SqlParameter parametar1 = new SqlParameter("@name", inputMinion[0]);
            SqlParameter parametar2 = new SqlParameter("@age", int.Parse(inputMinion[1]));
            SqlParameter parametar3 = new SqlParameter("@town", inputMinion[2]);
            SqlParameter parametar4 = new SqlParameter("@villainName", inputVillain);

            cmd.Parameters.Add(parametar1);
            cmd.Parameters.Add(parametar2);
            cmd.Parameters.Add(parametar3);
            cmd.Parameters.Add(parametar4);

            int affectedRows = (int)cmd.ExecuteNonQuery();

            if (affectedRows > 0)
                Console.WriteLine($"Successfully added {inputMinion[0]} to be minion of {inputVillain}.");
        }

        private static void InsertVillain(string inputVillain, SqlConnection dbCon)
        {
            string insertQuery = File.ReadAllText("./../../InsertVillain.sql");

            SqlCommand cmd = new SqlCommand(insertQuery, dbCon);

            SqlParameter parametar = new SqlParameter("@Name", inputVillain);

            cmd.Parameters.Add(parametar);

            int affectedRows = (int)cmd.ExecuteNonQuery();

            if (affectedRows > 0)
                Console.WriteLine($"Villain {inputVillain} was added to the database.");
        }

        private static void InsertTown(string town, SqlConnection dbCon)
        {
            string insertQuery = File.ReadAllText("./../../InsertTown.sql");

            SqlCommand cmd = new SqlCommand(insertQuery, dbCon);

            SqlParameter parametar = new SqlParameter("@town", town);

            cmd.Parameters.Add(parametar);

            int affectedRows = (int)cmd.ExecuteNonQuery();

            if (affectedRows > 0)
                Console.WriteLine($"Town {town} was added to the database.");

        }

    }
}
