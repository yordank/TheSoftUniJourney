﻿USE MinionsDB

DECLARE @TownsCount INT=(SELECT COUNT(*)
					   FROM Towns
					   WHERE TownName=@town)
IF(@TownsCount =0)
BEGIN
     INSERT INTO Towns(TownName)VALUES (@town)
	 SELECT 'TownInserted'
END

 