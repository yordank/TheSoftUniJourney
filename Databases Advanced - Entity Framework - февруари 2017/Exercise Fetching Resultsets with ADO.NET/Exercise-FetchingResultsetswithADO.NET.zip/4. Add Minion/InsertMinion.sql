﻿USE MinionsDB

DECLARE @townId INT=
(SELECT Id
   FROM Towns
  WHERE TownName=@town) 

INSERT INTO Minions(Name,Age,TownId)VALUES(@name,@age,@townId)

DECLARE @MinionId INT=(SELECT Id FROM Minions WHERE Name=@name)
DECLARE @VillainId INT=(SELECT Id FROM Villains WHERE Name=@villainName)
INSERT INTO VillainsMinions(VillainId,MinionId)
VALUES(@VillainId,@MinionId)