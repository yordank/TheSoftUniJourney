﻿USE MinionsDB

DECLARE @VillainCount INT=(SELECT COUNT(*)
					   FROM Villains
					   WHERE Name=@Name)
IF(@VillainCount = 0)
BEGIN
     INSERT INTO Villains
     VALUES(@Name,'evil')
END

