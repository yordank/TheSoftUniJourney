﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9.Increase_Age_Stored_Procedure
{
    class Program
    {
        static void Main(string[] args)
        {
            int id =int.Parse(Console.ReadLine());
            
            string serverName = "Server=HOME\\SQLEXPRESS; ";

            SqlConnection dbCon = new SqlConnection(
                       serverName +
                       "Database=MinionsDB;"+
                       "Integrated Security=true");
            dbCon.Open();

            using (dbCon)
            {
                string query = $"EXEC usp_GetOlder {id}";
                SqlCommand command = new SqlCommand(query, dbCon);
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"{reader["Name"]} {reader["Age"]}");
                    }

                }

            }
        }
    }
}
