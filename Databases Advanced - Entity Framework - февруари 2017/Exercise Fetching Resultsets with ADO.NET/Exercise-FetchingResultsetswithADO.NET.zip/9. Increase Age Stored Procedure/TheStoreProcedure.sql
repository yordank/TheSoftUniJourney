﻿
CREATE PROCEDURE usp_GetOlder (@Id INT)
AS
BEGIN 
   UPDATE Minions 
   SET Age=Age+1
   WHERE Id=@Id

   SELECT Name,
          Age
     FROM Minions
	WHERE Id=@Id
END