﻿ USE MinionsDB

 SELECT Name FROM Villains
 WHERE Id=@VillainId