﻿ USE MinionsDB

 SELECT 
        m.Name,
        m.Age 
  FROM VillainsMinions AS vm
  JOIN Villains AS v
    ON vm.VillainId=v.Id
  JOIN Minions AS m
    ON m.Id=vm.MinionId
 WHERE v.Id=@VillainId