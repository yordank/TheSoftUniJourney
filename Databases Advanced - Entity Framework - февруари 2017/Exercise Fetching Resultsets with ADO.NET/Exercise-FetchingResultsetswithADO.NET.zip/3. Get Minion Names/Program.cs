﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.Get_Minion_Names
{
    class Program
    {
        static void Main(string[] args)
        {
            string serverName = "Server=HOME\\SQLEXPRESS; ";
            SqlConnection dbCon = new SqlConnection(
                       serverName +
                       "Integrated Security=true");
            dbCon.Open();

            using (dbCon)
            {
                int villainsId = int.Parse(Console.ReadLine());

                string villainsNameByIdQuery = File.ReadAllText("./../../VillainsNameById.sql");

                SqlCommand cmd = new SqlCommand(villainsNameByIdQuery, dbCon);

                SqlParameter parametar = new SqlParameter("@VillainId", villainsId);

                cmd.Parameters.Add(parametar);

                SqlDataReader reader = cmd.ExecuteReader();

                string name = "";

                if (reader.Read())
                {
                    name = reader["Name"].ToString();
                    Console.WriteLine($"Villain: {name}");
                    reader.Close();


                    string findMinionsQuery = File.ReadAllText("./../../FindMinions.sql");
                    SqlCommand cmdFindMinions = new SqlCommand(findMinionsQuery, dbCon);
                    SqlParameter parametarFindMinions = new SqlParameter("@VillainId", villainsId);
                    cmdFindMinions.Parameters.Add(parametarFindMinions);

                    SqlDataReader readerMinions = cmdFindMinions.ExecuteReader();

                    int index = 0;

                     while(readerMinions.Read())
                     {
                        index++;
                        Console.WriteLine($"{index}. {readerMinions["Name"]} {readerMinions["Age"]}");
                        
                     }

                     if(index==0)
                     {
                        Console.WriteLine("(no minions)");
                     }


                }
                else
                {
                    Console.WriteLine($"No villain with ID {villainsId} exists in the database.");
                }


            }
        }
    }
}
