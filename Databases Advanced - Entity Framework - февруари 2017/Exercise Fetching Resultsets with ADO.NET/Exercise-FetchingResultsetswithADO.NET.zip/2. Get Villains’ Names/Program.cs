﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Get_Villains__Names
{
    class Program
    {
        static void Main(string[] args)
        {
            string serverName = "Server=HOME\\SQLEXPRESS; ";
            SqlConnection dbCon = new SqlConnection(
                       serverName +
                       "Integrated Security=true");
            dbCon.Open();

            using (dbCon)
            {
                GetVillainsNames(dbCon);

            }

        }

        private static void GetVillainsNames(SqlConnection dbCon)
        {
            string query = File.ReadAllText("./../../VillainsNames.sql");
            SqlCommand command = new SqlCommand(query, dbCon);
            SqlDataReader reader = command.ExecuteReader();

            using (reader)
            {
                while (reader.Read())
                {
                    Console.WriteLine($"{reader["Name"]} {reader["Count"]}");
                }

            }
        }


    }
}
