﻿USE MinionsDB;

SELECT v.Name,
       COUNT(*)  AS Count
  FROM VillainsMinions AS vm
  JOIN Villains AS v
    ON vm.VillainId=v.Id
  JOIN Minions AS m
    ON m.Id=vm.MinionId
 GROUP BY v.Name 		 
 HAVING COUNT(*)>3
