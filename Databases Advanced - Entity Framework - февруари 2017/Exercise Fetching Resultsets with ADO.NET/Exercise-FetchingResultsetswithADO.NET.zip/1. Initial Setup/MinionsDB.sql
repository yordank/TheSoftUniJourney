--CREATE DATABASE MinionsDB;

USE MinionsDB; 

CREATE TABLE Towns
(
Id INT PRIMARY KEY IDENTITY,
TownName VARCHAR(50),
CountryName VARCHAR(50),
)

CREATE TABLE Minions
(
Id INT PRIMARY KEY IDENTITY,
Name VARCHAR(20),
Age INT,
TownId INT,
FOREIGN KEY (TownId) REFERENCES Towns(Id)
)

CREATE TABLE Villains
(
Id INT PRIMARY KEY IDENTITY,
Name VARCHAR(50),
EvilnessFactor VARCHAR(20) CHECK (EvilnessFactor IN ('good','bad','evil','super evil')),
)

CREATE TABLE VillainsMinions
(
VillainId INT,
MinionId INT,
PRIMARY KEY(VillainId,MinionId),
FOREIGN KEY (VillainId) REFERENCES Villains(Id),
FOREIGN KEY (MinionId) REFERENCES Minions(Id)
)

INSERT INTO Towns VALUES
('Sofia','Bulgaria'),
('Varna','Bulgaria'),
('Paris','France'),
('Pernik','Bulgaria'),
('Moskow','Russia')

INSERT INTO Minions VALUES
('Ivan',21,1),
('Maria',18,1),
('Petar',25,2),
('Pier',29,3),
('Yury',20,5)

INSERT INTO Villains VALUES
('Misho','good'),
('Gosho','bad'),
('Todor','evil'),
('Tony','super evil'),
('Rumen','good')

INSERT INTO VillainsMinions VALUES
(1,1),
(1,2),
(1,3),
(1,4),
(1,5),
(2,1),
(2,2),
(2,3),
(3,1),
(4,1),
(4,2),
(4,3),
(4,4),
(5,1),
(5,2),
(5,3),
(5,4)