﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.Initial_Setup
{
    class Program
    {
        static void Main(string[] args)
        {
            string serverName = "Server=HOME\\SQLEXPRESS; ";
            SqlConnection dbCon = new SqlConnection(
                       serverName+
                       "Integrated Security=true");
            dbCon.Open();
            using (dbCon)
            {
                string query = File.ReadAllText("./../../MinionsDB.sql");
                SqlCommand createDBcommand = new SqlCommand("CREATE DATABASE MinionsDB", dbCon);
                createDBcommand.ExecuteNonQuery();
                SqlCommand command = new SqlCommand(query, dbCon);
                command.ExecuteNonQuery();
            }

            
         
        }
    }
}
