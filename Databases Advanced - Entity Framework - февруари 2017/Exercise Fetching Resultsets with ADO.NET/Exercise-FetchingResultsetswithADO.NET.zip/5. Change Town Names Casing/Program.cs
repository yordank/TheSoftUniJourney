﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5.Change_Town_Names_Casing
{
    class Program
    {
        static void Main(string[] args)
        {
            string country = Console.ReadLine();

            string serverName = "Server=HOME\\SQLEXPRESS; ";
            SqlConnection dbCon = new SqlConnection(
                       serverName +
                       "Integrated Security=true");
            dbCon.Open();

            using (dbCon)
            {
                int affectedRows = UpdateTowns(country, dbCon);

                if(affectedRows>0)
                SelectUpdatedTowns(country, dbCon);

            }

        }

        private static void SelectUpdatedTowns(string country, SqlConnection dbCon)
        {
            string selectUpdatedTownsQuery = File.ReadAllText("./../../SelectUpdatedTowns.sql");

            SqlCommand cmd = new SqlCommand(selectUpdatedTownsQuery, dbCon);

            SqlParameter parametar = new SqlParameter("@contryName", country);

            cmd.Parameters.Add(parametar);

            SqlDataReader reader = cmd.ExecuteReader();

            var Towns = new List<string>();

            while (reader.Read())
            {
                Towns.Add(reader["TownName"].ToString());

            }

            Console.WriteLine($"[{String.Join(", ", Towns)}]");
        }

        private static int UpdateTowns(string country, SqlConnection dbCon)
        {
            string villainsNameByIdQuery = File.ReadAllText("./../../UpdateTowns.sql");

            SqlCommand cmd = new SqlCommand(villainsNameByIdQuery, dbCon);

            SqlParameter parametar = new SqlParameter("@contryName", country);

            cmd.Parameters.Add(parametar);

            int affectedRows = (int)cmd.ExecuteNonQuery();
            
            var output = (affectedRows == 0) ? "No" : affectedRows.ToString();

            Console.WriteLine($"{output} town names were affected");

            return affectedRows;
        }
    }
}
