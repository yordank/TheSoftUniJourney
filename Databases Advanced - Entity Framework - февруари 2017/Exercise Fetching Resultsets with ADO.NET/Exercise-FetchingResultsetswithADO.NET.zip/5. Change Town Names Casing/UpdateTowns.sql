﻿USE MinionsDB

UPDATE Towns
SET TownName=UPPER(TownName)
WHERE CountryName=@contryName