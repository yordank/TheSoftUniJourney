﻿USE MinionsDB;

SELECT TownName 
  FROM Towns
 WHERE CountryName=@contryName