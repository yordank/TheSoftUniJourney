﻿USE MinionsDB
SELECT COUNT(*)
  FROM Minions