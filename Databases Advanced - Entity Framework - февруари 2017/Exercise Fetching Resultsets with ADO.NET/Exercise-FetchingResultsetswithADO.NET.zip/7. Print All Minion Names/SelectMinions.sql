﻿USE MinionsDB
SELECT Name 
  FROM Minions
