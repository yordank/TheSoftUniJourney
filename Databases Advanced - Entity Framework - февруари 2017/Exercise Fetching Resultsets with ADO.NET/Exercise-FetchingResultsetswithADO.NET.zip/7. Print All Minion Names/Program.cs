﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7.Print_All_Minion_Names
{
    class Program
    {
        static void Main(string[] args)
        {
            string serverName = "Server=HOME\\SQLEXPRESS; ";
            SqlConnection dbCon = new SqlConnection(
                       serverName +
                       "Integrated Security=true");
            dbCon.Open();

            using (dbCon)
            {
                string query = File.ReadAllText("./../../CountMinionsNames.sql");

                SqlCommand command = new SqlCommand(query, dbCon);

                int count=(int)command.ExecuteScalar();

                var list = new List<int>();

                 
               
                for (int i = 1; i <= count; i=i+2)
                    list.Add(i-1);

                if (count % 2 == 1)
                    count--;

                for (int j = count; j > 0; j -= 2)
                    list.Add(j-1);

               // Console.WriteLine(string.Join(",",list)); 


                SelectMinoions(dbCon,list);

            }


        }

        private static void SelectMinoions(SqlConnection dbCon, List<int> list )
        {
            string query = File.ReadAllText("./../../SelectMinions.sql");

            SqlCommand command = new SqlCommand(query, dbCon);

            SqlDataReader reader = command.ExecuteReader();

            var result = new string[list.Count()];

            int count = list.Count();

           
            using (reader)
            {
                int index = 0;
                while (reader.Read())
                {
                    result[list[index]]=reader["Name"].ToString();
                    index++;
                }

                Console.WriteLine(string.Join("\n",result));


            }


        }
    }
}
