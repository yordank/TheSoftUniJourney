﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class MainCLass
{
    static void Main()
    {
        List<string> persons = Console.ReadLine().Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToList();
        List<string> products = Console.ReadLine().Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToList();


        List<Person> people = new List<Person>();
        List<Product> product = new List<Product>();


        for (int i = 0; i < persons.Count; i++)
        {
            string[] args = persons[i].Split('=');
            try
            {
                string personName = args[0];
                string personMoney = args[1];
                people.Add(new Person(personName, decimal.Parse(personMoney)));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }
        }

        for (int i = 0; i < products.Count; i++)
        {
            string[] args = products[i].Split('=');
            try
            {
                string productName = args[0];
                string productCost = args[1];
                product.Add(new Product(productName, decimal.Parse(productCost)));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }

        }

        string line;
        while ((line = Console.ReadLine()) != "END")
        {
            string[] args = line.Split();

            string personName = args[0];

            string productName = args[1];

            if (string.IsNullOrWhiteSpace(personName) || string.IsNullOrEmpty(personName))
            {
                Console.WriteLine("Name cannot be empty");
                return;
            }
            if (string.IsNullOrWhiteSpace(productName) || string.IsNullOrEmpty(productName))
            {
                Console.WriteLine("Name cannot be empty");
                return;
            }

            var person = people.FirstOrDefault(x => x.Name == personName);
            person.BuyProduct(product.FirstOrDefault(x => x.Name == productName));
        }


        foreach (var item in people)
        {
            Console.WriteLine($"{item.Name} - {string.Join(", ", item.ShowBag())}");
        }
    }
}